# pyplanemono-minimal

This is a minimised version of the PyPlaneMono project, which is a calculation suite for the geometry of the plane grating monochromator. This repository contains only only the core calculation and visualisation functionalities and no GUI components
and is not capable of interacting with SHADOW as a pre-processor. For full functionality, refer to pyplanemono. This is meant to be distributed with the online interface of the PyPlaneMono project with maximum portability.

